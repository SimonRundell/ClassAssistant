import { useState, useEffect } from 'react';
import './App.css';
import ClassList from './ClassList';

function App() {
  return (
    <>
      <h1>ClassList</h1>
      <ClassList />
    </>
  );
}

export default App;