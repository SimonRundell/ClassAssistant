import React, { useEffect, useState } from 'react';
import './App.css';

const returnDiscipline = (discValue) => {
  switch (discValue) {
    case 0:
      return ' ';
    case 1:
      return 'Least Invasive Interaction';
    case 2:
      return 'Warning';
    case 3:
      return 'Compass';
    case 4:
      return 'Red Card';
    default:
      return 'Unknown';
  }
}

const disciplineColour = (discValue) => {
  switch (discValue) {
    case 0:
      return 'green';
    case 1:
      return 'yellow';
    case 2:
      return 'amber';
    case 3:
      return 'red';
    case 4:
      return 'red';
    default:
      return 'green';
  }
}

function ClassList() {
  const [students, setStudents] = useState([]);
  const [groupedStudents, setGroupedStudents] = useState([]);
  const [sliderValue, setSliderValue] = useState(4); // Default value set to 4
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());

  useEffect(() => {
    fetch('/data/students.json')
      .then(response => response.json())
      .then(data => setStudents(data));
  }, []);

  useEffect(() => {
    const grouped = students.slice(0, sliderValue);
    setGroupedStudents(grouped);
  }, [students, sliderValue]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleClick = (index) => {
    const updatedStudents = [...students];
    const [movedStudent] = updatedStudents.splice(index, 1);
    updatedStudents.push(movedStudent);
    setStudents(updatedStudents);
  };

  const handleSliderChange = (event) => {
    setSliderValue(event.target.value);
  };

  const handleStudentClick = (student) => {
    setSelectedStudent(student);
  };

  const handleAddCredit = (event) => {
    event.stopPropagation();
    if (selectedStudent) {
      const updatedStudents = students.map(student =>
        student === selectedStudent ? { ...student, credits: student.credits + 1 } : student
      );
      setStudents(updatedStudents);
      setSelectedStudent({ ...selectedStudent, credits: selectedStudent.credits + 1 });
    }
  };

  const handleSubtractCredit = (event) => {
    event.stopPropagation();
    if (selectedStudent) {
      const updatedStudents = students.map(student =>
        student === selectedStudent ? { ...student, credits: student.credits - 1 } : student
      );
      setStudents(updatedStudents);
      setSelectedStudent({ ...selectedStudent, credits: selectedStudent.credits - 1 });
    }
  };

  const handleCallStudent = () => {
    if (selectedStudent) {
      const index = students.findIndex(student => student === selectedStudent);
      const updatedStudents = [...students];
      const [movedStudent] = updatedStudents.splice(index, 1);
      movedStudent.timesCalled += 1; // Increment timesCalled
      updatedStudents.push(movedStudent);
      setStudents(updatedStudents);
      // Select the next student in the list
      const nextStudent = updatedStudents[0];
      setSelectedStudent(nextStudent);
    }
  };

  const handleNotesChange = (event) => {
    const updatedStudents = students.map(student =>
      student === selectedStudent ? { ...student, notes: event.target.value } : student
    );
    setStudents(updatedStudents);
    setSelectedStudent(prev => ({ ...prev, notes: event.target.value }));
  };

  const selectDiscipline = () => {
    if (selectedStudent) {
      const updatedStudents = students.map(student =>
        student === selectedStudent ? { ...student, discipline: (student.discipline + 1) % 5 } : student
      );
      setStudents(updatedStudents);
      setSelectedStudent({ ...selectedStudent, discipline: (selectedStudent.discipline + 1) % 5 });
    }
  };

  const generateReport = () => {
    const reportWindow = window.open('', '', 'width=800,height=600');
    const reportContent = `
      <html>
        <head>
          <title>Lesson Summary Report</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { text-align: center; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid black; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
          </style>
        </head>
        <body>
          <h1>Lesson Summary Report</h1>
          <p>Date and Time: ${new Date().toLocaleString()}</p>
          <table>
            <thead>
              <tr>
                <th>Student</th>
                <th>Times Called</th>
                <th>Credits</th>
                <th>Discipline</th>
              </tr>
            </thead>
            <tbody>
              ${students.map(student => `
                <tr>
                  <td>${student.firstName} ${student.lastName}</td>
                  <td>${student.timesCalled}</td>
                  <td>${student.credits}</td>
                  <td><span class="times-called ${disciplineColour(student.discipline)}">${returnDiscipline(student.discipline)}</span></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </body>
      </html>
    `;
    reportWindow.document.write(reportContent);
    reportWindow.document.close();
    reportWindow.print();
  };

  return (
    <>
    <div className="header">
      <div className="clock">{currentTime}</div>
      <button onClick={generateReport}>Generate Report</button>
    </div>
    <div className="classlist-container">
      <div className="container">
        <h2>Student List</h2>
        <input
          type="range"
          min="1"
          max={students.length}
          value={sliderValue}
          onChange={handleSliderChange}
          className="slider"
        />
        {sliderValue} students selected
        <ul className="student-list">
          {students.map((student, index) => (
            <li
              key={index}
              className="student-item"
              onClick={() => handleStudentClick(student)}
            >
              <span className="called-container">{student.firstName} {student.lastName} <span className="times-called"> {student.timesCalled}</span></span>
            </li>
          ))}
        </ul>
      </div>
      <div className="container">
        <h2>Student Details</h2>
        {selectedStudent && (
          <div className="student-info">
            <h3>{selectedStudent.firstName} {selectedStudent.lastName}</h3>
            <ul className="student-details">
              <li><span className="label">Credits:</span> <span className="value">{selectedStudent.credits}</span></li>
              <li><span className="label">Discipline:</span> <span className="value">{selectedStudent.discipline}</span></li>
              <li><span className="label">Support:</span> <span className="value">{selectedStudent.support ? 'Yes' : 'No'}</span></li>
              <li><span className="label">Times Called:</span> <span className="value">{selectedStudent.timesCalled}</span></li>
            </ul>
            <div className="notes-section">
              <h4>Notes:</h4>
              <textarea
                value={selectedStudent.notes}
                onChange={handleNotesChange}
                className="notes"
              />
            </div>
            <div className="buttons-together">
              <button onClick={handleAddCredit}>+</button>
              <button onClick={handleSubtractCredit}>-</button>
              <button className="button-wide" onClick={handleCallStudent}>Call</button>
            </div>
          </div>
        )}
      </div>
      <div className="container">
        <h2>Next Students to be Called</h2>
        <ul className="student-list">
          {groupedStudents.map((student, index) => (
            <li className="student-item" key={index}>
              <span className="called-container">{student.firstName} {student.lastName} <span className="times-called"> {student.timesCalled}</span></span>
            </li>
          ))}
        </ul>
      </div>
    </div>
    </>
  );
}

export default ClassList;